<?php include 'config/config.php' ?>
<?php include 'lib/Database.php' ?>
<?php
$db = new Database();
?>
<!DOCTYPE HTML>

<html>
	<head>
		<title>Members</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<h1><a href="index.php">HACK</a></h1>
				<a href="#nav">Menu</a>
			</header>

		<<?php include 'hnav.php'?>

		<!-- Main -->
			<section id="main" class="wrapper">
				<div class="container">

					<header class="major special">
						<h2>Members</h2>
						<p>Hardware Acceleration Club of KUET</p>
					</header>

					<a href="#" class="image fit"><img src="images/pc2.jpg" alt="" /></a>
					<?php
						$query = "select * from tbl_user";
						$mem = $db->select($query);
						$x=1;
						while($result = $mem->fetch_assoc()){
						?>
						
						<?php echo  $x.".".$result['first_name']." ".$result['last_name']; ?><br/>
						

					 <?php $x++; } ?>


					<p><a href ="https://drive.google.com/open?id=1l4lLZoABafxI-oogpaHR1bq5eZUxLhEa"><b>Click to know HACK Committee 2018</b></p>

				</div>
			</section>

<?php include 'footer.php'?>