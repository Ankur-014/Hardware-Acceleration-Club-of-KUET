<!DOCTYPE HTML>

<html>
	<head>
		<title>About</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<h1><a href="index.php">HACK</a></h1>
				<a href="#nav">Menu</a>
			</header>

		<?php include 'hnav.php'?>

		<!-- Main -->
			<section id="main" class="wrapper">
				<div class="container">

					<header class="major special">
						<h2>About Us</h2>
						<p>Hardware Acceleration Club of KUET</p>
					</header>

					<a href="#" class="image fit"><img src="images/pic.jpg" alt="" /></a>
					<p>HACK stands for Hardware Acceleration Club of KUET. The members of HACK especially works on embedded systems development.

HACK has developed some Robots like-
  -SKIM-H, the first intelligent ROBOT of Bangladesh.
  -Multi ROBOT, two robot can communicate with each other and can make a map of an area.
  -M ROBOT, a voice controlled ROBOT.
  -Wayfarer, a garbage man ROBOT.
  -Fast Line Tracer Robot
and some others.

HACK has implemented various projects like-
  -Home automation.
  -Online Heart rate monitoring system.
  -Pressure and temperate monitoring system of Human body.
  -Local Area Network using head phone.
  -Portable Face Recognizer.
and many more.

The members of HACK are now working on some innovative and challenging projects including:
  -Maze Solver Robot

This facebook group works as a communication medium to share the ideas and knowledge between the members and others who are interested in embedded system development. </p>

				</div>
			</section>

<?php include 'footer.php'?>