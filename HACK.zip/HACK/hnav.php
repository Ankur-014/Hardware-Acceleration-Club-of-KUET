
		<!-- Nav -->
			<nav id="nav">
				<ul class="links">
					<li><a href="index.php">Home</a></li>
					<li><a href="instructors.php">Instructors</a></li>
					<li><a href="members.php">Members</a></li>		
					<li><a href="online.php">Online Order</a></li>
					<li><a href="notice.php">Noticeboard</a></li>
					<li><a href="qa.php">Comments</a></li>
					<li><a href="login.php">Login</a></li>

				</ul>
			</nav>