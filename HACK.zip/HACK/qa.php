<?php include 'config/config.php' ?>
<?php include 'lib/Database.php' ?>
<?php
$db = new Database();
?>
<!DOCTYPE HTML>

<html>
	<head>
		<title>Noticeboard</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<h1><a href="index.php">HACK</a></h1>
				<a href="#nav">Menu</a>
			</header>

		<?php include 'hnav.php'?>

		<!-- Main -->
			<section id="main" class="wrapper">
				<div class="container">

					<header class="major special">
						<h2>Comments</h2>
						<p>Hardware Acceleration Club of KUET</p>
					</header>

					<?php
						$query = "select * from tbl_cmnt";
						$notice = $db->select($query);
						while($result = $notice->fetch_assoc()){
						?>
						
						<h3><a href="#"><?php echo  $result['name']; ?></a></h3>
					
						<?php echo $result['message']; ?>
						<p><?php echo $result['time']; ?></p>

						
					
					<?php } ?>

				</div>
			</section>

<?php include 'footer.php'?>